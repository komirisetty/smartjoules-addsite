import boto3 
import logging

iotclient = boto3.client('iot', region_name='ap-south-1')
sqsclient = boto3.client('sqs', region_name='ap-south-1')


def createAQueue(siteid):
    """

    # Function which basically setups the queue and configures it on given params as defined in earlier created queues. 

    """
    try:
        response = sqsclient.create_queue(
            QueueName='recentDataQ_' + siteid,
            Attributes={

                'VisibilityTimeout': '25',
                'MaximumMessageSize': '262144',
                'MessageRetentionPeriod': '180',
                'DelaySeconds': '0',
                'ReceiveMessageWaitTimeSeconds': '0'
            }
        )   
        print("Printing response for queue...")
        return(response)

    except Exception as identifier:
        logging.exception(identifier)
        return False


def addarule(siteid):
    """
    #Function which basically setups the new rule and configures it on given params as defined in earlier created rules.
    """
    try:    
        rullname_siteid = siteid.replace("-","_")
        response = iotclient.create_topic_rule(
            ruleName=rullname_siteid + '_CalcParms',
            topicRulePayload={
                'sql': 'select * from "' + siteid + '/data/+/recent"',
                'description': 'rule to listen to site data from the site ' + siteid,
                'actions': [
                    {

                        'sqs': {
                            'roleArn': 'arn:aws:iam::878252606197:role/service-role/iotToSQSRoleBeta',
                            'queueUrl': 'https://sqs.ap-south-1.amazonaws.com/878252606197/recentDataQ_' + siteid,
                            'useBase64': False
                        }
                    },
                ],
                'ruleDisabled': False,
                'awsIotSqlVersion': '2016-03-23',
                'errorAction': {

                    's3': {
                        'roleArn': 'arn:aws:iam::878252606197:role/service-role/IoTtoS3ErrorRole',
                        'bucketName': 'sqs-errored-values',
                        'key': 'ssh/${topic()}/${timestamp()}'

                    }
                }
            }

        )
        print("Printing response for rule.. ")
        return(response)

    except Exception as identifier:
        logging.exception(identifier)
        return False
