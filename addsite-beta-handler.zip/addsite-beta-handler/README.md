# New Site Addition

What this Lambda function does and why? 
Basically at the aws end whenever a new client is to be added there are certain things that are needed to be done. This function does a few of those tasks.
    Tasks:
        --> Creates a new IOT rule 
        --> Creates a new Queue.
    Both these things happen at us-west-2 region with given siteid coming at the event of this lambda.


    ## How to trigger this function? 

    ```
    aws lambda invoke --function-name arn:aws:lambda:us-west-2:878252606197:function:addsite-prod-hello --region us-west-2 --payload '{"siteid":"enter the siteid here"}' /dev/stdout 1>/dev/null
    ```
    Don't forget to replace with your siteid. 
    