import json
import time
from helper import createAQueue, addarule

"""
What this Lambda function does and why?
Basically at the aws end whenever a new client is to be added there are certain things that are needed to be done. This function does a few of those tasks.
    Tasks:
        --> Creates a new IOT rule
        --> Creates a new Queue.
    Both these things happen at us-west-2 region with given siteid coming at the event of this lambda.
"""


def handler(event, context):
    """
    Called with siteid : abcd in the event, Creates an IOT rule and creates a queue as needed
    """

    try:
        print("Printing the event")
        print(event)
        print("--------------------------")
        print("Starting to work for Site ID : ")
        print(event['siteid'])
        siteid = event['siteid']
        print(siteid)
        # calling the create a queue function in order
        createAQueue(siteid)
        time.sleep(0.1)
        # calling add a rule function which will create a rule for the new siteid
        addarule(siteid)
        response = {
            "statusCode": 200,
            "body": " All Good! "
        }
    except Exception as E:
        response = {
            "statusCode": 500,
            "body": "Something has gone wrong, Please check the logs." + str(E)
        }
    print(response)
    return response
