import unittest
from unittest.mock import MagicMock, patch, Mock
import sys
import logging
res = sys.path[0]
path = res.rsplit('/', 1)
sys.path.insert(0, path[0])
import handler


class Testhandler(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    @patch('handler.createAQueue')
    @patch('handler.addarule')
    def test_hello(self, a, b):
        data = {
            "siteid": 'mcgh'
        }
        res = handler.hello(data, '')
        self.assertEqual(res['statusCode'], 200)

    @patch('handler.createAQueue')
    @patch('handler.addarule')
    def test_error_hello(self, a, b):
        data = {
            "siteId": 'mcgh'
        }
        res = handler.hello(data, '')
        self.assertEqual(res['statusCode'], 500)
