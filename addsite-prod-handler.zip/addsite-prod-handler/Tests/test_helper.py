import unittest
from unittest.mock import MagicMock, patch, Mock
import sys
import logging
res = sys.path[0]
path = res.rsplit('/', 1)
sys.path.insert(0, path[0])
import helper


class Testhelper(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def getMockedClient(self, ex=False):
        client = Mock()
        if ex:
            client.create_queue.side_effect = Exception("unable to Create queue")
            client.create_topic_rule.side_effect = Exception("Unabel to add rule")
        else:
            client.create_queue.return_value = {"res": "Queue Created"}
            client.create_topic_rule.return_value = {"res": "Topic added"}
        return client

    def test_createAQueue(self):
        helper.sqsclient = self.getMockedClient()
        res = helper.createAQueue('mgch')
        self.assertIsInstance(res, dict)

    def test_error_createAQueue(self):
        helper.sqsclient = self.getMockedClient(ex=True)
        res = helper.createAQueue('mgch')
        self.assertIsInstance(res, bool)

    def test_addarule(self):
        helper.iotclient = self.getMockedClient()
        res = helper.addarule('mgch')
        self.assertIsInstance(res, dict)

    def test_error_addarule(self):
        helper.iotclient = self.getMockedClient(ex=True)
        res = helper.addarule('mgch')
        self.assertIsInstance(res, bool)


