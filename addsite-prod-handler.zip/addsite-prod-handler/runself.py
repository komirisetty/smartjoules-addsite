import handler

siteid = input("input site id:\n")

handler.handler({"siteid":"kaomsarc-hyd"}, False)